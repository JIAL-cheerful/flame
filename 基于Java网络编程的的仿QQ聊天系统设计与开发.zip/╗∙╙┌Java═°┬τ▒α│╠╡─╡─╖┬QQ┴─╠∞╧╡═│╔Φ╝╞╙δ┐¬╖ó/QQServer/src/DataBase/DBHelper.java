package DataBase;

import java.sql.*;

/**
 *	���ݿ��װ��
 */
public class DBHelper {
    private static final String driver="com.mysql.jdbc.Driver";
    private static final String url="jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf-8";
    private static final String username="root";
    private static final String password="123456";
    private static  Connection con=null;
    //��̬����븺���������
    static
    {
        try {
            Class.forName(driver);
            con=DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }



    //У���û�
    public static boolean  selectByUernamePassword(String username,String password) throws SQLException {
        Statement stmt = null;
        ResultSet rs = null;
        boolean flag = false;
        try {
            stmt =con.createStatement();
            String sql = "select * from user where username = '"+username+"' and password = '"+password+"'";
            System.out.println(sql);
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                if(rs.getString(1).equals(username) && rs.getString(2).equals(password)){
                    flag = true;
                }
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            if(rs!=null)
                rs.close();
            if(stmt!=null)
                stmt.close();
        }

        if (flag)
            return true;
        else
            return false;
    }

    public static boolean registerByUernamePassword(String username,String password) throws SQLException {
        Statement stmt = null;
        ResultSet rs = null;
        boolean flag = true;

        try {
            stmt =con.createStatement();
            String sql = "select * from user where username = '"+username+"' ";
            System.out.println(sql);

            rs = stmt.executeQuery(sql);
            while (rs.next()) {

                if(rs.getString(1).equals(username)){
                    flag = false;
                }
            }
            if(flag){
                String sql1 = "insert into user values('" + username + "','" + password + "')";
                System.out.println(sql1);
                stmt.execute(sql1);
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            if(rs!=null)
                rs.close();
            if(stmt!=null)
                stmt.close();
        }
        return flag;

    }
}