package Frame;

import Service.QQServer;

/**
 * ���ഴ��QQserver����
 */
public class QQFrame {
    public static void main(String[] args){
        new QQServer();
    }
}
