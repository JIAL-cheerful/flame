package Service;

import Common.Message;
import Common.MessageType;

import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *����/�����ṩ����Ϣ��صķ��񷽷�
 */



public class MessageClientService {

    /**
     *
     * @param content
     * @param senderId
     */
    public void sendMessageToAll(String content, String senderId){
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_TOALL_MES);
        message.setSender(senderId);
        message.setContent(content);
        message.setSendTime(new java.util.Date().toString());//����ʱ��
        System.out.println(senderId + "�� ������ ˵��" + content);
        //���ͷ����

        try {
            ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    /**
     *
     * @param content Ҫ���͵���Ϣ
     * @param senderId �����ߵ��û���
     * @param getterId �����ߵ��û���
     */
    public void sendMessageToOne(String content, String senderId, String getterId){
        //����һ��message����
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_COMM_MES);
        message.setSender(senderId);
        message.setGetter(getterId);
        message.setContent(content);
        message.setSendTime(new java.util.Date().toString());//����ʱ��
        System.out.println(senderId + "��" + getterId + "˵��" + content);
        //���ͷ����

        try {
            ObjectOutputStream oos = new ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}
