package Service;

import Common.Message;
import Common.MessageType;
import Common.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class UserRegisterServer {
    private User user = new User();
    private Socket socket;

    public int regieterUser(int rol, String userId, String pwd){
        user.setUserId(userId);
        user.setPasswd(pwd);
        user.setRol(rol);
        try {
            socket = new Socket(InetAddress.getByName("127.0.0.1"), 9999);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            oos.writeObject(user);  //����User����

            //��ȡ�ӷ���˻ظ���һ��message����
            ObjectInputStream osi = new ObjectInputStream(socket.getInputStream());
            Message ms = (Message) osi.readObject();

            if(ms.getMesType().equals(MessageType.MESSAGE_REGISTER_SUCCEED)){
                return  1;
            } else if (ms.getMesType().equals(MessageType.MESSAGE_REGISTER_ALDREEAD)) {
                return 2;
            } else if (ms.getMesType().equals(MessageType.MESSAGE_REGISTER_FALSE)) {
                return 3;
            }else{
                return 0;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            try {
                socket.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
