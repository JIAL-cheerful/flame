package View;

import Common.Message;
import Common.MessageType;
import Common.USERUSER;
import Service.*;
import Utils.Utility;

import javax.sound.midi.Receiver;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * �˵�����
 */
public class QQView extends JFrame{

    private boolean loop = true;    //�����Ƿ���ʾ�˵�
    private String key = "";        ///�û�����
    //���ڵ�¼��������ע���û�
    public UserClientService userClientService = new UserClientService();
    private UserRegisterServer userRegisterServer = new UserRegisterServer();
    private MessageClientService messageClientService = new MessageClientService();     //������

    private FIleClientServer fIleClientServer = new FIleClientServer();
    public static void main(String[] args){
        QQView qqView = new QQView();
        qqView.setBounds(600, 300, 300, 200);
        qqView.setTitle("��¼����");
    }



    JTextField userIdText;
    JPasswordField passwordField;
    JButton loginBtn;
    JButton registerBtn;
    JTabbedPane tabbedPane;

    String userId;
    String pwd;

    public QQView() {
        init();
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //��¼��ڵļ�����
        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userId = userIdText.getText();
                pwd = passwordField.getText();

                if(userClientService.checkUser(1, userId, pwd)){
                    USERUSER.userid = userId;
                    USERUSER.password = pwd;
                    setVisible(false);

                    JFrame afterLogin = new JFrame();
                    afterLogin.setBounds(550, 250, 350, 300);
                    afterLogin.setVisible(true);

                    tabbedPane = new JTabbedPane(JTabbedPane.TOP);
                    tabbedPane.add("��ʾ�����û�", new CheckOnlineUser());
                    tabbedPane.add("Ⱥ����Ϣ", new SendMessageToAll());
                    tabbedPane.add("˽����Ϣ", new SendMessageToOne());
                    tabbedPane.add("�����ļ�", new SendFileToOne());
                    tabbedPane.validate();
                    afterLogin.add(tabbedPane, BorderLayout.CENTER);
                    afterLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                }else{
                    JOptionPane.showMessageDialog(null, "�˺��������", "��Ϣ����", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        //ע�ᰴť�ļ�����
        registerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                userId = userIdText.getText();
                pwd = passwordField.getText();
                if(userRegisterServer.regieterUser(0, userId, pwd) == 1){
                    JOptionPane.showMessageDialog(null, "�˺�ע��ɹ������ص�½", "��Ϣ����", JOptionPane.WARNING_MESSAGE);
                    System.out.println("\n===========�˺�ע��ɹ������ص�½==========");
                } else if (userRegisterServer.regieterUser(0, userId, pwd) == 2) {
                    JOptionPane.showMessageDialog(null, "�˺��Ѵ���,���ص�½", "��Ϣ����", JOptionPane.WARNING_MESSAGE);
                    System.out.println("\n===========�˺��Ѵ���,���ص�½==========");
                }else if (userRegisterServer.regieterUser(0, userId, pwd) == 3) {
                    JOptionPane.showMessageDialog(null, "ע��ʧ�ܣ����ص�½", "��Ϣ����", JOptionPane.WARNING_MESSAGE);
                    System.out.println("\n===========ע��ʧ�ܣ����ص�½==========");
                }
            }
        });
    }


    class SendMessageToOne extends JPanel{
        SendMessageToOne(){
            setLayout(null);
            setVisible(true);
            add(new JLabel("������Ҫ���͵���Ϣ:")).setBounds(20, 20, 120, 30);
            JTextField mesFiled = new JTextField(40);
            mesFiled.setBounds(160, 20, 140, 20);
            add(mesFiled);
            add(new JLabel("������Ҫ���͵��û�:")).setBounds(20, 60, 120, 30);
            JTextField uidFiled = new JTextField(40);
            uidFiled.setBounds(160, 60, 140, 20);
            add(uidFiled);
            JButton button = new JButton("����");
            button.setBounds(130, 90, 60, 20);
            add(button);


            JTextArea area = new JTextArea(5, 5);
            area.setBounds(40,120, 250, 100 );
            add(area);
            ClientConnectServerThread.setSendMesToOneArea(area);


            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String content = mesFiled.getText();
                    String getterId = uidFiled.getText();
                    messageClientService.sendMessageToOne(content, userId, getterId);
                }
            });

        }
    }

    class SendFileToOne extends JPanel {
        SendFileToOne(){
            setLayout(null);
            setVisible(true);
            add(new JLabel("��������ļ���ַ:")).setBounds(20, 20, 120, 30);
            JTextField mesFiled = new JTextField(40);
            mesFiled.setBounds(160, 20, 140, 20);
            add(mesFiled);

            add(new JLabel("������ܵ��û�ID:")).setBounds(20, 60, 120, 30);
            JTextField getterIdText = new JTextField(40);
            getterIdText.setBounds(160, 60, 140, 20);
            add(getterIdText);

            add(new JLabel("����Է����ܵ�ַ:")).setBounds(20, 100, 120, 30);
            JTextField uidFiled = new JTextField(40);
            uidFiled.setBounds(160, 100, 140, 20);
            add(uidFiled);

            JButton button = new JButton("����");
            button.setBounds(130, 140, 60, 20);
            add(button);

            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fIleClientServer.sendFileToOne(mesFiled.getText(), uidFiled.getText(), userId, getterIdText.getText());
                }
            });
        }
    }

    class SendMessageToAll extends JPanel {
        SendMessageToAll(){
            setLayout(null);
            setVisible(true);
            add(new JLabel("������Ҫ���͵���Ϣ:")).setBounds(20, 20, 120, 30);
            JTextField mesFiled = new JTextField(40);
            mesFiled.setBounds(160, 20, 140, 20);
            add(mesFiled);

            JButton button = new JButton("����");
            button.setBounds(130, 90, 60, 20);
            add(button);

            JTextArea area = new JTextArea(5, 5);
            area.setBounds(40,120, 250, 100 );
            add(area);
            ClientConnectServerThread.setSendMesToAllArea(area);

            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String content = mesFiled.getText();
                    messageClientService.sendMessageToAll(content, userId);
                }
            });
        }
    }

    class CheckOnlineUser extends JPanel{
        CheckOnlineUser(){
            JTextArea onolineArea;
            onolineArea =new JTextArea(10,20);
            add(onolineArea);
            JButton button = new JButton("�鿴");
            button.setBounds(50, 180, 50,30);
            add(button);


            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    userClientService.onlineFriendList();
                    ClientConnectServerThread.setOnlineUserArea(onolineArea);
                }
            });


        }
    }


    void init(){

        setLayout(null);
        add(new JLabel("�û�����")).setBounds(40, 40, 50, 20);
        userIdText = new JTextField(20);
        userIdText.setBounds(100, 40, 150, 20);
        add(userIdText);
        add(new JLabel("��    �룺")).setBounds(40, 70, 50, 20);
        passwordField = new JPasswordField(20);
        passwordField.setBounds(100, 70, 150, 20);
        add(passwordField);
        loginBtn = new JButton("��¼");
        loginBtn.setBounds(60, 110, 70, 20);
        add(loginBtn);
        registerBtn = new JButton("ע��");
        registerBtn.setBounds(160, 110, 70, 20);
        add(registerBtn);

    }



    //��ʾ���˵�
//    private  void mainMenu(){
//
//        while(loop) {
//            System.out.println("============��ӭ��¼������==========");
//            System.out.println("\t\t 1 ��½ϵͳ");
//            System.out.println("\t\t 2 �û�ע��");
//
//            System.out.println("\t\t 9 �˳�ϵͳ");
//
//            System.out.println("���������ѡ��");
//            key = Utility.readString(1);
//
//            switch (key) {
//                case "1":
//                    System.out.println("�������û���");
//                    String userId = Utility.readString(50);
//                    System.out.println("������ ����");
//                    String pwd = Utility.readString(50);
//                    //��Ҫ����������֤�Ƿ�Ϸ���
//                    //UserClientService[�û���¼/ע��]
//                    if(userClientService.checkUser(1, userId, pwd)){
//
//                        System.out.println("============��ӭ���û�" + userId + "����½�ɹ�==========");
//                        while(loop){
//                            System.out.println("\n============����ͨ�Ŷ����˵����û�" + userId + "��==========");
//                            System.out.println("\t\t 1 ��ʾ�����û����б�");
//                            System.out.println("\t\t 2 Ⱥ����Ϣ");
//                            System.out.println("\t\t 3 ˽�ĺ���");
//                            System.out.println("\t\t 4 �����ļ�");
//                            System.out.println("\t\t 9 �˳�ϵͳ");
//                            System.out.println("���������ѡ��");
//                            key = Utility.readString(1);
//                            switch (key){
//                                case "1":
//                                    //������дһ����������ȡ�����û��б�
//                                    userClientService.onlineFriendList();
//                                    break;
//                                case "2":
//                                    System.out.println("��������Դ��˵�Ļ���");
//                                    String s = Utility.readString(100);
//                                    //����һ����������Ϣ��װ��message�����ͷ����
//                                    messageClientService.sendMessageToAll(s, userId);
//                                    break;
//                                case "3":
//                                    System.out.println("��������������û����������û���:");
//                                    String getterId = Utility.readString(50);
//                                    System.out.println("��������˵�Ļ���");
//                                    String content = Utility.readString(100);
//                                    //��дһ������������Ϣ���͸������
//                                    messageClientService.sendMessageToOne(content, userId, getterId);
//
//                                    break;
//                                case "4":
//                                    System.out.println("��������Ҫ���͵��û�");
//                                    getterId = Utility.readString(50);
//                                    System.out.println("�����뷢���ļ���·������ʽ d:\\xx.jpg)");
//                                    String src = Utility.readString(100);
//                                    System.out.println("��������ļ����͵��Է����ĸ�·��");
//                                    String dest = Utility.readString(100);
//                                    fIleClientServer.sendFileToOne(src, dest, userId, getterId);
//
//                                    break;
//                                case "5":
//                                    break;
//                                case "6":
//                                    break;
//                                case "9":
//                                    //����һ�������������������Ƴ���Ϣ
//                                    userClientService.logout();
//                                    loop = false;
//                                    break;
//                            }
//                        }
//                    }else{
//                        System.out.println("========��½ʧ��========");
//
//                    }
//                    break;
//                case "2":
//                    System.out.println("��������Ҫע����û���");
//                    String nuserId = Utility.readString(50);
//                    System.out.println("�������������");
//                    String npwd = Utility.readString(50);
//                    System.out.println("\n===========ע���˺���==========");
//                    if(userRegisterServer.regieterUser(0, nuserId, npwd) == 1){
//                        System.out.println("\n===========�˺�ע��ɹ������ص�½==========");
//                    } else if (userRegisterServer.regieterUser(0, nuserId, npwd) == 2) {
//                        System.out.println("\n===========�˺��Ѵ���,���ص�½==========");
//                    }else if (userRegisterServer.regieterUser(0, nuserId, npwd) == 3) {
//                        System.out.println("\n===========ע��ʧ�ܣ����ص�½==========");
//                    }
//                    break;
//                case "9":
//                    loop = false;
//                    break;
//
//            }
//        }
//
//    }
}
