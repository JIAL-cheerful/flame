package Common;

public class USERUSER {
    public static String userid;
    public static String password;


}
